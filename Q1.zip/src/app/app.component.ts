import { Component, OnInit } from '@angular/core';
import {PersonsService} from './persons.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'JsonAPI';
  data: Array<any>
  totalLength: any 
  page: number=1 
  
  constructor(private personholder: PersonsService){
    this.data = new Array<any>()
    
  }
  ngOnInit(){
    this.getDataFromAPI()
    
  }
  getDataFromAPI(){
    this.personholder.getData().subscribe((data) =>{
      console.log(data)
      this.data = data
      this.totalLength =data.length

    })
  }
}
